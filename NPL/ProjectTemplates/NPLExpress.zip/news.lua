local express = NPL.load('express');
local cookie = express.Cookie;
local router = express.Router:new();


router:get('/', function(req, res, next)
	
	-- ɾ�� cookie ʾ��
	local c = cookie:new({
		name = 'myname',
		maxAge = -1
	});
	res:appendCookie(c);

	-- �� session ʾ��
	local s = req.session:get('myname');
	local v = nil;
	if(s) then
		v = s.value;
	end

	-- URL ���ݵĲ���
	local param_id = req.params.id;

	res:render('news', {id = req.params.id, session = v});
end);


NPL.export(router);