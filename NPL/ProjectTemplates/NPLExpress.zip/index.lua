local express = NPL.load('express');
local cookie = express.Cookie;
local router = express.Router:new();


router:get('/', function(req, res, next)
	-- cookie ʾ��
	local c = cookie:new({
		name = 'myname',
		value = 'caoyongfeng'
	});
	res:appendCookie(c);

	-- session ʾ��
	req.session:set({
		name = 'myname',
		value = 'abcdefg',
		maxAge = 120
	});

	res:render('index', { id = 100 });
end);


NPL.export(router);