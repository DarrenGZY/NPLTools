--[[
	Author: CYF
	Date: 2017��1��30��
	EMail: me@caoyongfeng.com
	Desc: ����NPLExpress��WebӦ�ü�ʾ��
]]

local express = NPL.load('express');

local router_index = NPL.load('./routes/index');
local router_news = NPL.load('./routes/news');
local router_user = NPL.load('./routes/user');
local router_upload = NPL.load('./routes/upload');


local app = express:new();


app:set('views', 'views');
app:set('view engine', 'lustache');

app:use(express.static('public'));
app:use(express.session());


app:use('/news/:id', router_news);
app:use('/user', router_user);
app:use('/upload', router_upload);
app:use('/', router_index);

app:use(function(req, res, next)
	res:setStatus(404);
	res:send({err=404});
end);


NPL.export(app);