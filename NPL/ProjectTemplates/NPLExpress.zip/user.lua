local express = NPL.load('express');
local router = express.Router:new();


router:get('/', function(req, res, next)
	
	local user = {
		id = 1,
		name = 'cyf',
		gender = '��'
	};

	-- table �ᱻתΪ JSON
	res:send(user);
end);


NPL.export(router);